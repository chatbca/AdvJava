/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package b3.tax;

import java.rmi.*;

/**
 *
 * @author HP
 */
public interface ITax extends Remote{
    double ComputeTax(double Salary) throws RemoteException;
}
