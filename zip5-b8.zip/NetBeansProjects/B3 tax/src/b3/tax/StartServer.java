/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package b3.tax;

import java.rmi.AlreadyBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;


import java.rmi.registry.Registry;

/**
 *
 * @author HP
 */
public class StartServer {
    public static void main(String[] args) throws RemoteException, AlreadyBoundException  {
        ITaxServer it  = new ITaxServer();
        Registry reg = LocateRegistry.createRegistry(18888);
        reg.bind("TaxServer", it);
        System.out.println("Server Staarted..........");
    }
    
}
