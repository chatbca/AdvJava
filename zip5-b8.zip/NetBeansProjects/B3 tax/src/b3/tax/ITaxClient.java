/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package b3.tax;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;

/**
 *
 * @author HP
 */
public class ITaxClient {
    public static void main(String[] args) throws RemoteException, NotBoundException {
        Registry reg =LocateRegistry.getRegistry(18888);
        ITax it = (ITax) reg.lookup("TaxServer");
        double salary;
        String ans="y";
        Scanner input= new Scanner(System.in);
        do{
            System.out.print("Enter your Annual salary:");
            salary=input.nextDouble();
            
            System.out.print("Income tax is: "+it.ComputeTax(salary));
            input.nextLine();
            System.out.print("\nDo You  want to continue[y/n]:");
            ans= input.nextLine();
        }while(ans.toLowerCase().charAt(0)=='y');
    }
}
