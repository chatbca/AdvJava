/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package b3.tax;

import java.rmi.RemoteException;
import java.rmi.server.*;

/**
 *
 * @author HP
 */
public class ITaxServer extends UnicastRemoteObject implements ITax{
    public ITaxServer() throws RemoteException{
    super();
    }

    @Override
    public double ComputeTax(double Salary) throws RemoteException {
        if (Salary <= 300000) {
            return 0.0;
        } else if (Salary <= 600000) {
            return(Salary - 300000) * 0.05;
        } else if (Salary <= 900000) {
             return(600000 - 300000) * 0.05 + (Salary - 600000) * 0.1;
        } else if (Salary <= 1200000) {
            return(600000 - 300000) * 0.05 + (900000 - 600000) * 0.1 + (Salary- 900000) * 0.15;
        } else if (Salary <= 1500000) {
            return(600000 - 300000) * 0.05 + (900000 - 600000) * 0.1 + (1200000 - 900000) * 0.15 + (Salary - 1200000) * 0.20;
        } else {
            return(600000 - 300000) * 0.05 + (900000 - 600000) * 0.1 + (1200000 - 900000) * 0.15 + (1500000 - 1200000) * 0.20 + (Salary- 1500000) * 0.30;
        }
        
    
    }
    
}
