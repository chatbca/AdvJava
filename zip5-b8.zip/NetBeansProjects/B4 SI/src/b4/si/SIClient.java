/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package b4.si;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;

/**
 *
 * @author HP
 */
public class SIClient {
    public static void main(String[] args) throws RemoteException, NotBoundException {
        Registry reg=LocateRegistry.getRegistry(18888);
        ISimpleIntrest si = (ISimpleIntrest) reg.lookup("SimpleIntrest");
        Scanner input = new Scanner(System.in);
        double p,t,r;
        String ans="n";
        do{
            System.out.println("SIMPLE INTREST CALCULATION");
            System.out.print("Principle:");
            p = input.nextDouble();
            System.out.print("Time:");
            t = input.nextDouble();
            System.out.print("Rate:");
            r = input.nextDouble();
            System.out.print("Simple Intrest is:-"+si.ComputeIntrest(p, t, r));
            System.out.println("\nDou want to continue[y/n]...?");
            input.nextLine();
            ans=input.nextLine();
        }while(ans.toLowerCase().charAt(0)=='y');
    }
}
