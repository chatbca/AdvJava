/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package b4.si;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

/**
 *
 * @author HP
 */
public class SIServer extends UnicastRemoteObject implements ISimpleIntrest {
   public SIServer() throws RemoteException{
   super();
   }
    @Override
    public double ComputeIntrest(double p, double t, double r) throws RemoteException {
        return(p*t*r)/100;
    }
    
}
