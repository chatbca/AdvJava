/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package b4.si;

import java.rmi.AlreadyBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/**
 *
 * @author HP
 */
public class StartServer {
    public static void main(String[] args) throws RemoteException, AlreadyBoundException {
        SIServer si = new SIServer();
        Registry reg = LocateRegistry.createRegistry(18888);
        reg.bind("SimpleIntrest", si);
        System.out.println("Server Started...:)");
    }
}
