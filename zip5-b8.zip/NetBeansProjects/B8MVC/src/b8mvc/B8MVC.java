
package b8mvc;

import java.util.Scanner;

/**
 *
 * @author HP
 */
public class B8MVC {

    
    public static void main(String[] args) {
        String rNo,sName;
        int m1,m2,m3;
        Scanner in= new Scanner(System.in);
        System.out.print("Enter Roll No:");
        rNo= in.nextLine();
        System.out.print("Enter your Name:");
        sName=in.nextLine();
        System.out.print("Enter your Marks in 3 Subjects:");
        m1=in.nextInt();
        m2=in.nextInt();
        m3=in.nextInt();
        
        StudentModel sm = new StudentModel(rNo, sName, m1, m2, m3);
        StudentView sv= new StudentView();
        StudentCntroller sc= new StudentCntroller(sm, sv);
        sc.UpdateView();
        
        
        
        
    }
    
}
