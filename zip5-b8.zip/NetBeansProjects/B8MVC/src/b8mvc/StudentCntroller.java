/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package b8mvc;

/**
 *
 * @author HP
 */
public class StudentCntroller {
    private StudentModel model;
    private StudentView view;

    public StudentCntroller(StudentModel model, StudentView view) {
        this.model = model;
        this.view = view;
    }
    
    public void UpdateView(){
 view.displayResult(model.getRolno(), model.getName(), model.getM1(),model.getM2(),model.getM3(), model.getResult(),model.getGrade());
}
    
}
