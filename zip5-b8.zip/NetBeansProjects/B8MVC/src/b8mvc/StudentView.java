/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package b8mvc;

/**
 *
 * @author HP
 */
public class StudentView {
    public void displayResult(String rNo, String sName, int m1,int m2,int m3, String result, String grade){
        System.out.println("---------------------------------RESULT------------------------------");
        System.out.println("\tRoll No\t Name\t\t Marks1\tMarks2\tMarks3\tResult\t\tGrade");
        System.out.println("----------------------------------------------------------------------");
        System.out.println("\t"+rNo+"\t"+sName+"\t\t"+m1+"\t"+m2+"\t"+m3+"\t"+result+"\t\t"+grade);
        System.out.println("----------------------------------------------------------------------");
    
    }
}
